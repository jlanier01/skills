---
name: project-wiki
version: 2.3
description: "Automatically generate, maintain, de-duplicate, and health-check a compiled knowledge base (wiki) for Claude Projects. The wiki is a five-file stable corpus plus one small operational ledger (wiki_state.md) so routine upkeep is a one-file swap. Use whenever a project has source files that would benefit from a lightweight index layer, especially projects with 3+ source files, complex cross-references, or ongoing multi-session work. Trigger when the user mentions 'wiki', 'knowledge base', 'index files', 'project orientation', 'context management', 'health check', 'out of sync', or 'is the wiki current', or when a working session has modified source material. If a project has wiki files (wiki_index.md, etc.) present, always read them FIRST and run the session-start health check BEFORE touching raw source docs."
---

# Project Wiki v2.3 · Self-Checking Knowledge Base for Claude Projects

## Why this skill exists, and the constraint it works around

A compiled wiki keeps a consistent mental model across conversations and cuts token waste: read lightweight wiki files first, pull source only when needed. The hard constraint is that **project files are read-only**. The only way to change one is to delete the old version and upload the new one by hand, and a re-upload does not always re-index immediately. So every wiki update has a real manual cost. The whole design minimizes how often, and how many, files must be swapped.

## What changed across versions

- **v1** put integrity at write time, which is unreliable, so wikis drifted until the user asked.
- **v2** moved integrity to read time (a deterministic session-start health check), added a machine-checkable state block, a pending-sync log, a sync-debt threshold, and legacy migration.
- **v2.3** splits the wiki into a **five-file stable corpus** plus **one small operational ledger** (`wiki_state.md`). The churn (manifest, pending log, session log) lives in the ledger, so routine upkeep is a one-file swap. The five stable files move only when project substance moves.

There is no background process between chats. "Automatic" means bound to the read-time trigger that always fires.

## The wiki layout (v2.3)

### Stable corpus (5 files, change only on substance changes)

| File | Role |
|---|---|
| `wiki_index.md` | File registry and topic lookup. Human-readable inventory of every project file. |
| `wiki_concepts.md` | Concept registry: terms, structures, architecture, grouped and cross-referenced. |
| `wiki_[domain]-tracker.md` | Domain tracker: items with consistent attributes in table form. |
| `wiki_[entities].md` | Profiles for people, systems, companies, characters. |
| `wiki_continuity-tracker.md` | Locked decisions, resolved and open conflicts, cross-file threads, version lineage. |

### Operational ledger (1 file, the routine-swap file)

| File | Role |
|---|---|
| `wiki_state.md` | The machine-checkable `wiki-state` block (manifest + invariants + pending_count), the pending-sync log, and the session log. The volatile surface you swap routinely. |

### File types in a wiki'd project

| Type | What it is | Examples |
|---|---|---|
| **Wiki files** | The orientation layer: the 5 stable files + `wiki_state.md`. Always read first. | the six above |
| **Compiled-source files** | Long-form derived content the wiki summarizes but does not replace. Cataloged, not part of the wiki. | a signal-library narrative |
| **Raw source files** | The primary artifacts. | `.docx`, `.pptx`, `.xlsx`, `.html`, images |

> **Naming convention:** every wiki file carries the `wiki_` prefix so the orientation layer is instantly identifiable in projects with many files. A diagnostic relationship map, when present, is `wiki_relationship-map.md` and is cataloged in the manifest as an expected file, but is not part of the core orientation set.

## The Wiki State block

`wiki_state.md` opens with one fenced, machine-parseable block. This is the source of truth the health check diffs against.

````
```wiki-state
last_sync: YYYY-MM-DD
wiki_files: wiki_index.md, wiki_concepts.md, wiki_[domain]-tracker.md, wiki_[entities].md, wiki_continuity-tracker.md, wiki_state.md
compiled_source: file-a.md, file-b.md
expected_project_files: <full list of every file that should be in project knowledge>
invariants: key=value; key=value      # e.g. signal_classes=263; org_metrics=153
pending_count: 0
```
````

- **expected_project_files** is the manifest. The check diffs the actual project directory against it, catching a removed file or an added-but-uncataloged one.
- **invariants** are counts or facts that must reconcile to a source of truth (usually workbook IDs). The check recomputes them when the source is present.
- **pending_count** mirrors the pending-sync log length and drives the sync-debt threshold.

The health check auto-discovers this block in whichever file holds it, so the layout can evolve without breaking the check.

## Session-Start Health Check (runs every session, first action)

The first action in any wiki'd project, before requested work. It replaces "review the wiki when asked" with "the wiki reports its own health on entry." The check reads files; it never writes them. A healthy project produces nothing.

### Procedure

1. Read `wiki_state.md` and parse the state block (or auto-discover whichever file holds it).
2. Run the audit script, or its logic by hand if code execution is unavailable:
   - **File diff:** actual project files vs `expected_project_files`. Flag additions and removals.
   - **Wiki completeness:** all wiki files present.
   - **Reference integrity:** every wiki-internal file reference resolves.
   - **Invariant reconciliation:** recompute each invariant from its source when present.
   - **Sync debt:** read `pending_count` and `last_sync`.
3. Emit one verdict and act per tier.

### Verdict tiers

| Verdict | Meaning | Action |
|---|---|---|
| **GREEN** | In sync. No file diff, all wiki files present, references resolve, invariants match, pending_count 0. | One quiet line at most, then proceed. Do not nag. |
| **YELLOW** | Minor drift: uncataloged files, nonzero pending_count below threshold, or a small invariant gap. | One line naming the drift, offer to reconcile, then proceed unless redirected. |
| **RED** | Structural break: a wiki file or referenced file missing, no state block, or a wrong invariant leaking into work. | Flag prominently before proceeding; recommend fixing first. |

Quiet when GREEN. Loudness scales with severity, never with routine.

### Embedded audit script

Run at session start (`python3 wiki_healthcheck.py /mnt/project`). Deterministic and dependency-light; the invariant recount runs only if `openpyxl` and the workbook are present.

```python
#!/usr/bin/env python3
import os, re, sys, glob

PROJ = sys.argv[1] if len(sys.argv) > 1 else "/mnt/project"

def read(p):
    try: return open(p, encoding="utf-8", errors="ignore").read()
    except Exception: return ""

def parse_state(t):
    m = re.search(r"```wiki-state(.*?)```", t, re.S); s={}
    if not m: return s
    for line in m.group(1).strip().splitlines():
        if ":" in line:
            k,v=line.split(":",1); s[k.strip()]=v.strip()
    return s

def listfmt(s): return [x.strip() for x in re.split(r"[,\n]", s) if x.strip()] if s else []

# Auto-discover whichever .md holds the wiki-state block (prefix-agnostic)
state={}; state_file=None
for p in sorted(glob.glob(os.path.join(PROJ,"*.md"))):
    st=parse_state(read(p))
    if st: state, state_file = st, os.path.basename(p); break

actual={os.path.basename(p) for p in glob.glob(os.path.join(PROJ,"*"))}
expected=set(listfmt(state.get("expected_project_files",""))); wiki_files=set(listfmt(state.get("wiki_files","")))
red,yellow=[],[]
if not state: red.append("No wiki-state block found in any .md file")
mw=sorted(f for f in wiki_files if f not in actual)
if mw: red.append(f"Missing wiki file(s): {', '.join(mw)}")
rem=sorted(expected-actual); add=sorted(actual-expected-wiki_files)
if rem: red.append(f"Manifest files absent from project: {', '.join(rem)}")
if add: yellow.append(f"Uncataloged file(s) in project: {', '.join(add)}")
for wf in wiki_files:
    txt=read(os.path.join(PROJ,wf))
    for ref in set(re.findall(r"`([\w\-\.]+\.md)`", txt)):
        if ref in wiki_files and ref not in actual:
            red.append(f"{wf} references missing wiki file {ref}")
inv={}
for kv in re.split(r"[;\n]", state.get("invariants","")):
    if "=" in kv: k,v=kv.split("=",1); inv[k.strip()]=v.strip()
try:
    import openpyxl
    for fn,sheet,key in [("GTM_OS_Signal_Library_Metrics.xlsx","All Signals","signal_classes"),
                         ("Org_Capability_Metric_Library_v2_0.xlsx","All Metrics","org_metrics")]:
        p=os.path.join(PROJ,fn)
        if key in inv and os.path.exists(p):
            wb=openpyxl.load_workbook(p,data_only=True)
            if sheet in wb.sheetnames:
                rows=list(wb[sheet].iter_rows(values_only=True))
                ids=[r[0] for r in rows[1:] if r and r[0] and re.match(r"^[A-Z]+-L?\d",str(r[0]))]
                if str(len(ids))!=str(inv[key]): red.append(f"Invariant {key}={inv[key]} but source has {len(ids)}")
except ImportError:
    yellow.append("openpyxl absent: invariants not recomputed")
try: pending=int(state.get("pending_count","0"))
except ValueError: pending=0
if pending>=3: yellow.append(f"Sync debt: {pending} pending (>= threshold)")
verdict="RED" if red else ("YELLOW" if yellow else "GREEN")
print(f"WIKI HEALTH: {verdict}  (state {state_file or 'NONE'}, last_sync {state.get('last_sync','?')}, pending {state.get('pending_count','?')})")
for p in red: print("  RED   ·",p)
for p in yellow: print("  YELLOW·",p)
if verdict=="GREEN": print("  In sync. Proceed.")
```

## Migrating a Legacy Wiki (to v2.3)

Custom skills are account-level, so this skill applies to every project at once. Wiki files are project-scoped, so each project migrates when you are inside it. There is no cross-project batch. The skill makes this scale by detecting legacy state on entry.

### Legacy detection

A project is legacy when the check finds: no `wiki-state` block in any `.md`, unprefixed wiki files (`_index.md`, etc.), or a v1 structure with no manifest. In all cases the check returns RED. Offer to migrate before doing requested work.

### Procedure

1. Run the migrate script (`python3 wiki_migrate.py <project_dir> <output_dir>`). It renames the stable files to the `wiki_` convention, rewrites cross-references, and creates a `wiki_state.md` ledger with a state-block scaffold, an empty pending log, and a session-log stub. It lists ambiguous files for review rather than touching them.
2. Fill the `invariants: TODO` line with project-specific facts, or remove it.
3. Have the user upload the `wiki_` files plus `wiki_state.md` and delete the old unprefixed ones. A partial swap leaves old files flagged as uncataloged.
4. Re-run the health check to confirm GREEN.

### Embedded migrate script

```python
#!/usr/bin/env python3
"""Migrate a legacy project wiki to the v2.3 layout: wiki_ prefix on the stable corpus
plus a separate wiki_state.md ledger (state block + pending log + session log).
Usage: python3 wiki_migrate.py <project_dir> <output_dir>
Writes migrated copies (never edits source). Conservative: reports ambiguous files instead of touching them."""
import os, re, sys, glob, datetime

proj = sys.argv[1] if len(sys.argv) > 1 else "/mnt/project"
out  = sys.argv[2] if len(sys.argv) > 2 else "/home/claude/wiki_migrated"
os.makedirs(out, exist_ok=True)

def read(p):
    try: return open(p, encoding="utf-8", errors="ignore").read()
    except Exception: return ""

allfiles = sorted(os.path.basename(p) for p in glob.glob(os.path.join(proj,"*")) if os.path.isfile(p))
EXACT = {"_index.md","_concepts.md","continuity-tracker.md","entities.md","relationship-map.md"}
PAT = re.compile(r".*-(tracker|entities)\.md$|^(characters|stakeholders|concept-definitions|architecture-entities)\.md$")
legacy = [f for f in allfiles if not f.startswith("wiki_") and (f in EXACT or PAT.match(f))]
if not legacy:
    print("No legacy (unprefixed) wiki files detected. Nothing to migrate.")
    sys.exit(0)

rename = {f: "wiki_"+f.lstrip("_") for f in legacy}
for old,new in rename.items():
    t = read(os.path.join(proj,old))
    for a,b in rename.items(): t = t.replace(a,b)
    t = t.replace("wiki_wiki_","wiki_")
    open(os.path.join(out,new),"w",encoding="utf-8").write(t)

# Stable orientation files go in wiki_files; relationship-map stays a diagnostic (expected only)
core = [rename[f] for f in legacy if f != "relationship-map.md"] + ["wiki_state.md"]
expected = sorted(set(list(rename.values()) + [f for f in allfiles if f not in rename]) | {"wiki_state.md"})
today = datetime.date.today().isoformat()
ledger = ("```wiki-state\n"
          f"last_sync: {today}\n"
          f"wiki_files: {', '.join(core)}\n"
          "compiled_source: TODO\n"
          f"expected_project_files: {', '.join(expected)}\n"
          "invariants: TODO   # e.g. signal_classes=263; fill per project, then the check reconciles to source\n"
          "pending_count: 0\n"
          "```\n\n"
          "# Wiki State and Operational Ledger\n\n"
          "The volatile surface of the wiki: the machine-checkable state block above, the pending-sync log, "
          "and the session log. This is the file you swap routinely. The stable corpus moves only when project substance changes.\n\n"
          "## Pending Sync (un-applied)\n\n_None._\n\n"
          "## Session Log\n\n| Date | Changes |\n|---|---|\n"
          f"| {today} | Migrated to v2.3 layout: stable files renamed to wiki_ prefix, references rewritten, wiki_state.md ledger created. Fill invariants. |\n")
open(os.path.join(out,"wiki_state.md"),"w",encoding="utf-8").write(ledger)

print("MIGRATION REPORT (v2.3)")
print(f"  project: {proj}\n  output:  {out}\n  renamed:")
for old,new in rename.items(): print(f"    {old:34s} -> {new}")
print("  created: wiki_state.md  (state block + pending log + session log)")
print("\nNEXT STEPS: fill invariants in wiki_state.md, upload the wiki_ files plus wiki_state.md, delete the old unprefixed ones, re-run the health check.")
```

## Pending-Sync Log (in wiki_state.md, the cheap capture)

An append-only section in `wiki_state.md`. Recording a delta is far cheaper than reconciling the wiki, so it actually happens.

Append at the end of any session that did any of these mechanical things: created, modified, or removed a source file; wrote a deliverable to outputs; made or reversed a LOCKED decision or resolved a CONFLICT; changed a count, name, or invariant.

```
## Pending Sync (un-applied)
- [YYYY-MM-DD] <what changed> -> touches: <wiki files> [outputs: <files needing upload>]
```

One line per change; increment `pending_count`. Because this lives in the ledger, capturing a change is a one-file swap, not a regeneration of the stable corpus.

## Session Log (in wiki_state.md)

The chronological diary of what changed each session lives in `wiki_state.md`, not in the continuity tracker. It is volatile by nature and belongs with the ledger.

## Sync-Debt Threshold

At the session-start check, if `pending_count >= 3` OR the verdict is RED, recommend a consolidation before requested work. State it once. A consolidation applies the pending log, reconciles the manifest and invariants, runs the de-dup pass, resets `pending_count` to 0, and stamps `last_sync`. Default threshold is 3; tune to project velocity.

## Outputs-to-Project Gap

Deliverables written to outputs must be manually uploaded to project knowledge before the wiki can see them. This is the biggest silent-drift source. At the end of any session that wrote to outputs: list the artifacts, state plainly that they need uploading, and log them in the pending-sync log with an `outputs:` tag. Never assume an output file is in project knowledge next session.

## Maintenance, by cost

- **Routine (most sessions): one-file swap.** A logged decision, a pending entry, a session-log line, a count or manifest change touches only `wiki_state.md`. Swap that one small file.
- **Substance change: two files.** A new concept, entity, or locked decision touches the relevant stable file plus `wiki_state.md` (manifest or pending). A new source file touches the manifest now and gets its `wiki_index.md` inventory entry at the next consolidation.
- **Full consolidation (periodic, or on RED / debt threshold): all affected files.** Re-read sources, regenerate affected files (full-file regeneration over diffs), apply and clear the pending log, reconcile the manifest and invariants, run the de-dup pass, stamp `last_sync`, regenerate the relationship map, add a session-log entry.

Between consolidations, drift is tracked, not fixed. The pending log plus chat history keep Claude accurate, so the stable files do not need to be perfect every moment, only current when relied on cold (a fresh session, onboarding, a handoff).

## The De-Duplication Pass (a gate, not a virtue)

After any update, sweep all files and run this checklist:

- [ ] Merge duplicate entries; one canonical home, cross-referenced.
- [ ] Reconcile contradictions to the latest version.
- [ ] Collapse overlapping tracker rows.
- [ ] Prune entries whose backing source was removed.
- [ ] Confirm every cross-file reference resolves.

## Relationship Map

At meaningful complexity (15+ entities, multiple trackers, dozens of cross-references) or on request, generate a mermaid diagram: nodes are entities/concepts/tracker items, edges are cross-references/ownership/evolution, clusters group by file, color-coded by origin. It surfaces orphaned entries, over-connected nodes, dependency chains. Regenerate after a full refresh.

## Domain Adaptation

| Domain | Tracker | Entities | Continuity focus |
|---|---|---|---|
| TV/Film | wiki_episode-tracker | wiki_characters | timeline, arcs, planted threads |
| Software | wiki_feature-tracker | wiki_architecture-entities | API contracts, migration state |
| Research | wiki_paper-tracker | wiki_concept-definitions | findings chain, methodology |
| Business | wiki_workstream-tracker | wiki_stakeholders | decisions, dependencies, blockers |
| Book/Novel | wiki_chapter-tracker | wiki_characters | timeline, foreshadowing |

Pattern: index, concepts, domain tracker, entities, continuity, plus the wiki_state ledger.

## Constraints

- Wiki files are orientation aids, not replacements for source. Verify against source before changing source.
- The session-start health check is non-optional and is the first action.
- The de-dup pass is a gate, not a virtue. Skipping it is the top failure mode.
- The pending-sync append is the minimum capture every changing session. It is a one-file swap.
- Project files are read-only; minimize how often and how many files must be swapped. Route routine churn to `wiki_state.md`.
- Quiet when GREEN. Loudness scales with severity, never with routine.

## Changelog

- **v2.3** · Split into a five-file stable corpus plus a one-file operational ledger (`wiki_state.md`) holding the state block, pending log, and session log. Routine upkeep becomes a one-file swap; the stable corpus moves only on substance changes. Maintenance reorganized by cost. Migrate script now creates the ledger instead of injecting the block into the index.
- **v2.2** · Legacy-wiki migration built in: detection on entry plus a conservative migrate script. Clarified account-level skill vs project-scoped files.
- **v2.1** · `wiki_` filename prefix convention; audit script hardened to auto-discover the state block.
- **v2.0** · Read-time health check with tiers; machine-checkable state block; pending-sync log; sync-debt threshold; outputs-gap handling; reference-integrity and invariant reconciliation.
- **v1.0** · Five-file structure, read-wiki-first protocol, incremental and full-refresh maintenance, de-dup pass, relationship map.
