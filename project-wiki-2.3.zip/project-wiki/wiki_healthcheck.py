#!/usr/bin/env python3
import os, re, sys, glob

PROJ = sys.argv[1] if len(sys.argv) > 1 else "/mnt/project"

def read(p):
    try: return open(p, encoding="utf-8", errors="ignore").read()
    except Exception: return ""

def parse_state(t):
    m = re.search(r"```wiki-state(.*?)```", t, re.S); s={}
    if not m: return s
    for line in m.group(1).strip().splitlines():
        if ":" in line:
            k,v=line.split(":",1); s[k.strip()]=v.strip()
    return s

def listfmt(s): return [x.strip() for x in re.split(r"[,\n]", s) if x.strip()] if s else []

# Auto-discover whichever .md holds the wiki-state block (prefix-agnostic)
state={}; state_file=None
for p in sorted(glob.glob(os.path.join(PROJ,"*.md"))):
    st=parse_state(read(p))
    if st: state, state_file = st, os.path.basename(p); break

actual={os.path.basename(p) for p in glob.glob(os.path.join(PROJ,"*"))}
expected=set(listfmt(state.get("expected_project_files",""))); wiki_files=set(listfmt(state.get("wiki_files","")))
red,yellow=[],[]
if not state: red.append("No wiki-state block found in any .md file")
mw=sorted(f for f in wiki_files if f not in actual)
if mw: red.append(f"Missing wiki file(s): {', '.join(mw)}")
rem=sorted(expected-actual); add=sorted(actual-expected-wiki_files)
if rem: red.append(f"Manifest files absent from project: {', '.join(rem)}")
if add: yellow.append(f"Uncataloged file(s) in project: {', '.join(add)}")
for wf in wiki_files:
    txt=read(os.path.join(PROJ,wf))
    for ref in set(re.findall(r"`([\w\-\.]+\.md)`", txt)):
        if ref in wiki_files and ref not in actual:
            red.append(f"{wf} references missing wiki file {ref}")
inv={}
for kv in re.split(r"[;\n]", state.get("invariants","")):
    if "=" in kv: k,v=kv.split("=",1); inv[k.strip()]=v.strip()
try:
    import openpyxl
    for fn,sheet,key in [("GTM_OS_Signal_Library_Metrics.xlsx","All Signals","signal_classes"),
                         ("Org_Capability_Metric_Library_v2_0.xlsx","All Metrics","org_metrics")]:
        p=os.path.join(PROJ,fn)
        if key in inv and os.path.exists(p):
            wb=openpyxl.load_workbook(p,data_only=True)
            if sheet in wb.sheetnames:
                rows=list(wb[sheet].iter_rows(values_only=True))
                ids=[r[0] for r in rows[1:] if r and r[0] and re.match(r"^[A-Z]+-L?\d",str(r[0]))]
                if str(len(ids))!=str(inv[key]): red.append(f"Invariant {key}={inv[key]} but source has {len(ids)}")
except ImportError:
    yellow.append("openpyxl absent: invariants not recomputed")
try: pending=int(state.get("pending_count","0"))
except ValueError: pending=0
if pending>=3: yellow.append(f"Sync debt: {pending} pending (>= threshold)")
verdict="RED" if red else ("YELLOW" if yellow else "GREEN")
print(f"WIKI HEALTH: {verdict}  (state {state_file or 'NONE'}, last_sync {state.get('last_sync','?')}, pending {state.get('pending_count','?')})")
for p in red: print("  RED   ·",p)
for p in yellow: print("  YELLOW·",p)
if verdict=="GREEN": print("  In sync. Proceed.")
