#!/usr/bin/env python3
"""Migrate a legacy project wiki to the v2.3 layout: wiki_ prefix on the stable corpus
plus a separate wiki_state.md ledger (state block + pending log + session log).
Usage: python3 wiki_migrate.py <project_dir> <output_dir>
Writes migrated copies (never edits source). Conservative: reports ambiguous files instead of touching them."""
import os, re, sys, glob, datetime

proj = sys.argv[1] if len(sys.argv) > 1 else "/mnt/project"
out  = sys.argv[2] if len(sys.argv) > 2 else "/home/claude/wiki_migrated"
os.makedirs(out, exist_ok=True)

def read(p):
    try: return open(p, encoding="utf-8", errors="ignore").read()
    except Exception: return ""

allfiles = sorted(os.path.basename(p) for p in glob.glob(os.path.join(proj,"*")) if os.path.isfile(p))
EXACT = {"_index.md","_concepts.md","continuity-tracker.md","entities.md","relationship-map.md"}
PAT = re.compile(r".*-(tracker|entities)\.md$|^(characters|stakeholders|concept-definitions|architecture-entities)\.md$")
legacy = [f for f in allfiles if not f.startswith("wiki_") and (f in EXACT or PAT.match(f))]
if not legacy:
    print("No legacy (unprefixed) wiki files detected. Nothing to migrate.")
    sys.exit(0)

rename = {f: "wiki_"+f.lstrip("_") for f in legacy}
for old,new in rename.items():
    t = read(os.path.join(proj,old))
    for a,b in rename.items(): t = t.replace(a,b)
    t = t.replace("wiki_wiki_","wiki_")
    open(os.path.join(out,new),"w",encoding="utf-8").write(t)

# Stable orientation files go in wiki_files; relationship-map stays a diagnostic (expected only)
core = [rename[f] for f in legacy if f != "relationship-map.md"] + ["wiki_state.md"]
expected = sorted(set(list(rename.values()) + [f for f in allfiles if f not in rename]) | {"wiki_state.md"})
today = datetime.date.today().isoformat()
ledger = ("```wiki-state\n"
          f"last_sync: {today}\n"
          f"wiki_files: {', '.join(core)}\n"
          "compiled_source: TODO\n"
          f"expected_project_files: {', '.join(expected)}\n"
          "invariants: TODO   # e.g. signal_classes=263; fill per project, then the check reconciles to source\n"
          "pending_count: 0\n"
          "```\n\n"
          "# Wiki State and Operational Ledger\n\n"
          "The volatile surface of the wiki: the machine-checkable state block above, the pending-sync log, "
          "and the session log. This is the file you swap routinely. The stable corpus moves only when project substance changes.\n\n"
          "## Pending Sync (un-applied)\n\n_None._\n\n"
          "## Session Log\n\n| Date | Changes |\n|---|---|\n"
          f"| {today} | Migrated to v2.3 layout: stable files renamed to wiki_ prefix, references rewritten, wiki_state.md ledger created. Fill invariants. |\n")
open(os.path.join(out,"wiki_state.md"),"w",encoding="utf-8").write(ledger)

print("MIGRATION REPORT (v2.3)")
print(f"  project: {proj}\n  output:  {out}\n  renamed:")
for old,new in rename.items(): print(f"    {old:34s} -> {new}")
print("  created: wiki_state.md  (state block + pending log + session log)")
print("\nNEXT STEPS: fill invariants in wiki_state.md, upload the wiki_ files plus wiki_state.md, delete the old unprefixed ones, re-run the health check.")
