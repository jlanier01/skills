#!/usr/bin/env python3
"""Project Wiki health check. Reads files only, never writes.
Invariant specs are declared in the wiki-state block, not in this script, so the
script carries no project-specific detail and is safe to distribute as-is.
Usage: python3 wiki_healthcheck.py [project_dir]   (default /mnt/project)

Invariant spec syntax (one per line inside the wiki-state block, key prefixed inv.):
  inv.<name>: <expected> file=<source> [sheet="<sheet>"] [col=<A|0>] [match=<regex>]
Examples:
  inv.item_count:  120 file=inventory.xlsx sheet="Sheet1" col=A match=^[A-Z]+-\\d
  inv.row_count:   40  file=data.csv col=0
A spec with no file= is a declared fact and is not reconciled.
match= must be the LAST field; everything after it is treated as the literal regex.
"""
import os, re, sys, glob

PROJ = sys.argv[1] if len(sys.argv) > 1 else "/mnt/project"
WANT_JSON = "--json" in sys.argv[2:]

DATA_EXT = (".xlsx", ".xlsm", ".csv", ".tsv")

def read(p):
    """Return (text, status). status: 'ok' | 'missing' | 'unreadable'."""
    if not os.path.exists(p): return "", "missing"
    try: return open(p, encoding="utf-8", errors="ignore").read(), "ok"
    except Exception: return "", "unreadable"

def parse_state(t):
    m = re.search(r"```wiki-state(.*?)```", t, re.S); s = {}
    if not m: return s
    for line in m.group(1).strip().splitlines():
        if ":" in line:
            k, v = line.split(":", 1); s[k.strip()] = v.strip()
    return s

def listfmt(s):
    return [x.strip() for x in re.split(r"[,\n]", s) if x.strip()] if s else []

def col_to_idx(c):
    c = (c or "A").strip()
    if c.isdigit(): return int(c)
    idx = 0
    for ch in c.upper():
        if "A" <= ch <= "Z": idx = idx * 26 + (ord(ch) - 64)
    return idx - 1 if idx > 0 else 0

def parse_invariant(spec):
    """spec is the text after 'inv.<name>:'. Returns dict or None if unparseable."""
    spec = spec.strip()
    if not spec: return None
    # match= is the last field; isolate it so its regex can contain anything.
    rx = None; left = spec
    if " match=" in spec: left, rx = spec.split(" match=", 1)
    elif spec.startswith("match="): left, rx = "", spec[len("match="):]
    parts = left.split(None, 1)
    expected = parts[0] if parts else None
    rest = parts[1] if len(parts) > 1 else ""
    fm = re.search(r"file=(\S+)", rest)
    sm = re.search(r'sheet="([^"]*)"', rest) or re.search(r"sheet=(\S+)", rest)
    cm = re.search(r"col=(\S+)", rest)
    return {"expected": expected,
            "file": fm.group(1) if fm else None,
            "sheet": sm.group(1) if sm else None,
            "col": cm.group(1) if cm else "A",
            "match": rx}

def count_source(path, sheet, col_idx, pattern):
    """Count rows whose target cell matches pattern (or are non-empty if no pattern).
    Returns int count or None if the source could not be read."""
    ext = os.path.splitext(path)[1].lower()
    rows = None
    if ext in (".csv", ".tsv"):
        import csv
        delim = "\t" if ext == ".tsv" else ","
        with open(path, newline="", encoding="utf-8", errors="ignore") as f:
            rows = [tuple(r) for r in csv.reader(f, delimiter=delim)]
    elif ext in (".xlsx", ".xlsm"):
        import openpyxl  # guarded by caller
        wb = openpyxl.load_workbook(path, data_only=True, read_only=True)
        ws = wb[sheet] if sheet and sheet in wb.sheetnames else wb[wb.sheetnames[0]]
        rows = list(ws.iter_rows(values_only=True))
    if rows is None or len(rows) < 1: return 0
    rx = re.compile(pattern) if pattern else None
    n = 0
    for r in rows[1:]:  # skip header row
        if not r or col_idx >= len(r): continue
        cell = r[col_idx]
        if cell is None or str(cell).strip() == "": continue
        if rx is None or rx.match(str(cell)): n += 1
    return n

# --- discover the state block (prefer wiki_state.md; warn on duplicates) ---
blocks = []
for p in sorted(glob.glob(os.path.join(PROJ, "*.md"))):
    txt, _ = read(p)
    st = parse_state(txt)
    if st: blocks.append((os.path.basename(p), st))

state, state_file, dup_warn = {}, None, None
if blocks:
    preferred = [b for b in blocks if b[0] == "wiki_state.md"] or blocks
    state_file, state = preferred[0]
    if len(blocks) > 1:
        others = ", ".join(b[0] for b in blocks if b[0] != state_file)
        dup_warn = f"Multiple wiki-state blocks found (using {state_file}; also in: {others})"

actual = {os.path.basename(p) for p in glob.glob(os.path.join(PROJ, "*")) if os.path.isfile(p)}
expected = set(listfmt(state.get("expected_project_files", "")))
wiki_files = set(listfmt(state.get("wiki_files", "")))
red, yellow = [], []

if not state:
    red.append("No wiki-state block found in any .md file")
if dup_warn:
    yellow.append(dup_warn)

# wiki completeness + readability
for wf in sorted(wiki_files):
    txt, status = read(os.path.join(PROJ, wf))
    if status == "missing":
        red.append(f"Missing wiki file: {wf}")
    elif status == "unreadable":
        red.append(f"Wiki file unreadable: {wf}")

# manifest diff
rem = sorted(expected - actual)
add = sorted(actual - expected - wiki_files)
if rem: red.append(f"Manifest files absent from project: {', '.join(rem)}")
if add: yellow.append(f"Uncataloged file(s) in project: {', '.join(add)}")

# reference integrity: any wiki/source file named in backticks must exist
known = expected | wiki_files
for wf in wiki_files:
    txt, status = read(os.path.join(PROJ, wf))
    if status != "ok": continue
    for ref in set(re.findall(r"`([\w\-./]+\.(?:md|xlsx|xlsm|csv|tsv|pptx|docx|html|png|jpg))`", txt)):
        if ref in known and ref not in actual:
            red.append(f"{wf} references missing file {ref}")

# invariants: parse inv.* specs, reconcile any that name a present source
inv_specs = {k[4:]: parse_invariant(v) for k, v in state.items() if k.startswith("inv.")}
inv_specs = {k: v for k, v in inv_specs.items() if v}
reconcilable = {k: v for k, v in inv_specs.items() if v.get("file")}
if reconcilable:
    have_xlsx = True
    try: import openpyxl  # noqa
    except ImportError: have_xlsx = False
    for key, spec in reconcilable.items():
        src = spec["file"]
        path = os.path.join(PROJ, src)
        if not os.path.exists(path):
            yellow.append(f"Invariant {key}: source {src} not in project; not reconciled")
            continue
        if src.lower().endswith((".xlsx", ".xlsm")) and not have_xlsx:
            yellow.append(f"Invariant {key}: openpyxl absent; {src} not reconciled")
            continue
        try:
            got = count_source(path, spec["sheet"], col_to_idx(spec["col"]), spec["match"])
        except Exception as e:
            yellow.append(f"Invariant {key}: could not read {src} ({e}); not reconciled")
            continue
        if str(got) != str(spec["expected"]):
            red.append(f"Invariant {key}={spec['expected']} but {src} has {got}")

# sync debt: compare declared pending_count to actual pending-log lines, then threshold
declared = state.get("pending_count")
state_txt, _ = read(os.path.join(PROJ, state_file)) if state_file else ("", "")
logged = len(re.findall(r"^\s*-\s*\[\d{4}-\d{2}-\d{2}\]", state_txt, re.M))
try: pending = int(declared)
except (TypeError, ValueError): pending = logged
if declared is not None and str(logged) != str(declared):
    yellow.append(f"pending_count={declared} but pending log has {logged} entr{'y' if logged==1 else 'ies'}")
pending = max(pending, logged)
if pending >= 3:
    yellow.append(f"Sync debt: {pending} pending (>= threshold) -> run a consolidation "
                  "(apply pending log, reconcile manifest + invariants, de-dup, reset count, stamp last_sync)")

verdict = "RED" if red else ("YELLOW" if yellow else "GREEN")

if WANT_JSON:
    import json
    print(json.dumps({"verdict": verdict, "state_file": state_file,
                      "last_sync": state.get("last_sync"), "pending": pending,
                      "red": red, "yellow": yellow}, indent=2))
else:
    print(f"WIKI HEALTH: {verdict}  (state {state_file or 'NONE'}, "
          f"last_sync {state.get('last_sync','?')}, pending {pending})")
    for p in red: print("  RED   ·", p)
    for p in yellow: print("  YELLOW·", p)
    if verdict == "GREEN": print("  In sync. Proceed.")
