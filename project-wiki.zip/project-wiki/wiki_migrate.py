#!/usr/bin/env python3
"""Migrate a legacy project wiki to the v2.1+ convention.
Usage: python3 wiki_migrate.py <project_dir> <output_dir>
Writes migrated copies (never edits source). Conservative: reports ambiguous files instead of touching them."""
import os, re, sys, glob, datetime

proj = sys.argv[1] if len(sys.argv) > 1 else "/mnt/project"
out  = sys.argv[2] if len(sys.argv) > 2 else "/home/claude/wiki_migrated"
os.makedirs(out, exist_ok=True)

def read(p):
    try: return open(p, encoding="utf-8", errors="ignore").read()
    except Exception: return ""

allfiles = sorted(os.path.basename(p) for p in glob.glob(os.path.join(proj, "*")) if os.path.isfile(p))

# Legacy wiki detection: known roles + safe patterns, excluding already-prefixed
EXACT = {"_index.md","_concepts.md","continuity-tracker.md","entities.md","relationship-map.md"}
PAT = re.compile(r".*-(tracker|entities)\.md$|^(characters|stakeholders|concept-definitions|architecture-entities)\.md$")
legacy = [f for f in allfiles if not f.startswith("wiki_") and (f in EXACT or PAT.match(f))]

if not legacy:
    print("No legacy (unprefixed) wiki files detected. Nothing to migrate.")
    if any(f.startswith("wiki_") for f in allfiles):
        print("Project already uses the wiki_ convention.")
    sys.exit(0)

rename = {f: "wiki_" + f.lstrip("_") for f in legacy}

# Rewrite internal references and write renamed copies
for old, new in rename.items():
    t = read(os.path.join(proj, old))
    for a, b in rename.items():
        t = t.replace(a, b)
    t = t.replace("wiki_wiki_", "wiki_")
    open(os.path.join(out, new), "w", encoding="utf-8").write(t)

# Inject a wiki-state scaffold into the index if absent
idx_new = rename.get("_index.md")
injected = False
if idx_new:
    p = os.path.join(out, idx_new); t = read(p)
    if "```wiki-state" not in t:
        expected = sorted(rename.get(f, f) for f in allfiles)
        block = ("```wiki-state\n"
                 f"last_sync: {datetime.date.today().isoformat()}\n"
                 f"wiki_files: {', '.join(rename[f] for f in legacy if f in EXACT or f.endswith('-tracker.md') or f=='entities.md')}\n"
                 "compiled_source: TODO\n"
                 f"expected_project_files: {', '.join(expected)}\n"
                 "invariants: TODO   # e.g. signal_classes=263; fill per project, then the check reconciles to source\n"
                 "pending_count: 0\n"
                 "```\n\n")
        open(p, "w", encoding="utf-8").write(block + t); injected = True

print("MIGRATION REPORT")
print(f"  project: {proj}")
print(f"  output:  {out}")
print("  renamed:")
for old, new in rename.items(): print(f"    {old:32s} -> {new}")
print(f"  wiki-state block injected into index: {injected}")
ambiguous = [f for f in allfiles if f.endswith(".md") and not f.startswith("wiki_") and f not in legacy and f not in
             ("gtm-os-signal-library.md","gtm-os-signal-metrics.md","org-capability-metric-library.md")]
if ambiguous:
    print("  review (not auto-migrated, confirm if any are wiki files):")
    for f in ambiguous: print(f"    {f}")
print("\nNEXT STEPS: review output, fill invariants TODO, upload wiki_ files to the project, delete the old unprefixed ones.")
