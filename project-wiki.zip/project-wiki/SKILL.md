---
name: project-wiki
version: 2.1
description: "Automatically generate, maintain, de-duplicate, and health-check a compiled knowledge base (wiki) for Claude Projects. Use this skill whenever a project has source files that would benefit from a lightweight index layer, especially projects with 3+ source files, complex cross-references, or ongoing multi-session work. Trigger when the user mentions 'wiki', 'knowledge base', 'index files', 'project orientation', 'context management', 'health check', 'out of sync', or 'is the wiki current', or when a working session has modified source material. If a project has wiki files (wiki_index.md, wiki_concepts.md, etc.) present, always read them FIRST and run the session-start health check BEFORE touching raw source docs."
---

# Project Wiki v2.1 · Self-Checking Knowledge Base for Claude Projects

## What changed from v1

v1 put all integrity work at write time ("update the wiki at the end of any session that changed source"). Write time is the least reliable moment: there is no end-of-conversation hook, so the update only happened when the user prompted. Wikis drifted silently across many sessions.

v2 moves integrity to **read time**, the one trigger that fires automatically every session (the user always sends a first message, and the protocol is read-wiki-first). The check is **deterministic** (manifest + script), **tiered** (quiet when healthy, loud only on structural breaks), and **debt-bounded** (forced consolidation before drift can compound). Capture is decoupled from reconciliation: a cheap one-line pending log records what changed, and a periodic consolidation applies it.

There is no background process between chats. "Automatic" here means: bound to the read-time trigger that always fires, so drift surfaces on the next first message without the user asking.

## Purpose

Reduce token waste and keep a consistent mental model across conversations by keeping a compiled wiki between Claude and raw source files. Read lightweight wiki files first, pull source only when needed, and never let the wiki drift silently out of sync with the project.

## File types in a wiki'd project

Distinguish three kinds of file. The health check treats them differently.

| Type | What it is | Examples |
|---|---|---|
| **Wiki files** (exactly 5) | The orientation layer. Always read first. | `wiki_index.md`, `wiki_concepts.md`, `wiki_[domain]-tracker.md`, `wiki_[entities].md`, `wiki_continuity-tracker.md` |
| **Compiled-source files** | Long-form derived content the wiki summarizes but does not replace. Cataloged in `_index`, not part of the 5. | a signal-library narrative, a metrics narrative |
| **Raw source files** | The primary artifacts (docs, decks, workbooks, HTML). | `.docx`, `.pptx`, `.xlsx`, `.html`, images |

## The 5 Wiki Files

> **Naming convention (v2.1):** prefix every wiki file with `wiki_` so the orientation layer is instantly identifiable in projects with many files. The five roles are unchanged; only the filenames carry the prefix (`wiki_index.md`, `wiki_concepts.md`, `wiki_[domain]-tracker.md`, `wiki_[entities].md`, `wiki_continuity-tracker.md`). The audit script auto-discovers the state block, so the prefix can change without breaking the check.

Name them for the domain; the roles are fixed.

| File | Role |
|---|---|
| `wiki_index.md` | Master file registry, topic lookup, **and the Wiki State block** (see below). |
| `wiki_concepts.md` | Concept registry: every important term, entity, or structural element, grouped and cross-referenced. |
| `wiki_[domain]-tracker.md` | Domain tracker: items with consistent attributes in table form. |
| `wiki_[entities].md` | Quick-reference profiles for people, systems, companies, characters. |
| `wiki_continuity-tracker.md` | Locked decisions, resolved and open conflicts, cross-file threads, **the pending-sync log**, and the session log. |

---

## The Wiki State Block (new in v2)

`wiki_index.md` carries one fenced, machine-parseable block. This is the source of truth the health check diffs against. Keep it current as part of every consolidation.

````
```wiki-state
last_sync: YYYY-MM-DD
wiki_files: wiki_index.md, wiki_concepts.md, wiki_[domain]-tracker.md, wiki_[entities].md, wiki_continuity-tracker.md
compiled_source: file-a.md, file-b.md
expected_project_files: <full list of every file that should be in project knowledge>
invariants: key=value; key=value      # e.g. signal_classes=263; org_metrics=153
pending_count: 0
```
````

- **expected_project_files** is the manifest. The check diffs the actual project directory against it. A removed file (like a vanished `wiki_entities.md`) or an added-but-uncataloged file is detected deterministically.
- **invariants** are counts or facts that must reconcile to a source of truth (usually workbook IDs). The check recomputes them when the source is present.
- **pending_count** mirrors the pending-sync log length. Drives the sync-debt threshold.

---

## Session-Start Health Check (new in v2 · runs every session)

This is the first action in any wiki'd project, before any requested work. It replaces "review the wiki when asked" with "the wiki reports its own health on entry."

### Procedure

1. Read `wiki_index.md` and parse the Wiki State block.
2. Run the audit (script below, or its logic by hand if code execution is unavailable):
   - **File diff:** actual project files vs `expected_project_files`. Flag additions and removals.
   - **Wiki completeness:** all 5 wiki files present.
   - **Reference integrity:** every wiki-internal file reference resolves to a file that exists.
   - **Invariant reconciliation:** recompute each invariant from its source when present (e.g. count IDs in the workbook) and compare.
   - **Sync debt:** read `pending_count` and `last_sync`.
3. Emit one verdict and act per tier.

### Verdict tiers

| Verdict | Meaning | Action |
|---|---|---|
| **GREEN** | In sync. No file diff, all wiki files present, references resolve, invariants match, pending_count 0. | One quiet line at most ("Wiki in sync, last reviewed [date]"), then proceed with the user's request. Do not nag. |
| **YELLOW** | Minor drift. Uncataloged files, a nonzero pending_count below threshold, or an invariant off by a small amount. | One line naming the drift, offer to reconcile, then proceed with the request unless the user redirects. |
| **RED** | Structural break. A wiki file or a referenced file is missing, or an invariant is wrong in a way that is leaking into work. | Flag prominently before proceeding. Orientation is compromised; recommend fixing first. |

### Quiet-when-healthy rule

The check must be cheap and silent on GREEN. The user should feel it only when it matters. Loudness scales with severity, never with routine.

---

## Pending-Sync Log (new in v2 · the cheap capture)

Lives as an append-only section in `wiki_continuity-tracker.md`. The reason drift compounds is that each session's changes are not recorded until a full refresh. Recording a delta is far cheaper than reconciling the wiki, so it actually happens.

### When to append

At the end of any session that did any of the following (mechanical conditions, not judgment):

- Created, modified, or removed a source or compiled-source file.
- Wrote a deliverable to outputs.
- Made or reversed a LOCKED decision or resolved a CONFLICT.
- Changed a count, name, or invariant.

### Format

```
## Pending Sync (un-applied)
- [YYYY-MM-DD] <what changed> → touches: <wiki files> [outputs: <files needing upload>]
```

One line per change. Increment `pending_count` in the Wiki State block.

---

## Sync-Debt Threshold (new in v2 · the compounding guard)

The guarantee that many sessions never pile up again.

- At session-start health check, if `pending_count >= 3` OR the verdict is RED, **proactively recommend a consolidation** before doing the requested work. State it once, let the user decide.
- A consolidation applies the pending log to the wiki, reconciles the manifest and invariants, runs the de-dup pass, resets `pending_count` to 0, and stamps `last_sync`.
- Tune the threshold to the project's velocity. Three is a sensible default; high-velocity projects may want two.

---

## Outputs-to-Project Gap (new in v2 · the real leak)

In most projects, deliverables are written to an outputs area and must be manually uploaded to project knowledge before the wiki can see them. This is the single biggest silent-drift source.

At the end of any session that wrote to outputs:

1. List the artifacts produced.
2. State plainly that they need uploading to project knowledge for the wiki to track them.
3. Log them in the pending-sync log with an `outputs:` tag.

Never assume an output file is in project knowledge next session. Until uploaded, it is invisible to the check.

---

## Maintenance

### Incremental (every changing session, cheap)

1. Append to the pending-sync log (above). This is the minimum and it is non-optional.
2. If the change is small and self-contained (a single new entity, one renamed item), apply it to the affected wiki file now and clear that pending line.
3. Run the de-dup pass on any file you touched.

### Consolidation / full refresh (periodic or on RED / debt threshold)

Trigger when the user says the wiki is stale, `pending_count` hits the threshold, the health check returns RED, or more than ~30% of source has been rewritten.

1. Re-read all source files.
2. Regenerate the affected wiki files (full-file regeneration over diffs).
3. Apply and clear the pending-sync log.
4. Run the de-dup pass across all 5 files.
5. Update the Wiki State block: refresh `expected_project_files`, reconcile `invariants` from source, set `pending_count: 0`, stamp `last_sync`.
6. Regenerate the relationship map.
7. Add a session-log entry summarizing what changed.

---

## The De-Duplication Pass (unchanged intent, bound to a checklist)

After any update, sweep all 5 files and run this checklist. It is the single most common skipped step; treat it as a gate, not a virtue.

- [ ] Merge duplicate entries; one canonical home, cross-referenced from the others.
- [ ] Reconcile contradictions to the latest version.
- [ ] Collapse overlapping tracker rows.
- [ ] Prune entries whose backing source was removed or rewritten.
- [ ] Confirm every cross-file reference still resolves.

---

## Relationship Map

When the wiki reaches meaningful complexity (15+ entities, multiple trackers, dozens of cross-references), or on request, generate a **mermaid diagram**: nodes are entities/concepts/tracker items, edges are cross-references/ownership/evolution, clusters group by wiki file, color-coded by origin. It surfaces orphaned entries, over-connected nodes, dependency chains, and onboarding structure. Regenerate after a full refresh or major restructuring.

---

## Embedded Audit Script

Drop this in the container and run it at session start (`python3 wiki_healthcheck.py /mnt/project`). It is deterministic and dependency-light. The workbook recount runs only if `openpyxl` and the workbook are present. Adjust paths and invariant keys per project.

```python
#!/usr/bin/env python3
import os, re, sys, glob

PROJ = sys.argv[1] if len(sys.argv) > 1 else "/mnt/project"

def read(p):
    try: return open(p, encoding="utf-8", errors="ignore").read()
    except Exception: return ""

def parse_state(t):
    m = re.search(r"```wiki-state(.*?)```", t, re.S); s={}
    if not m: return s
    for line in m.group(1).strip().splitlines():
        if ":" in line:
            k,v=line.split(":",1); s[k.strip()]=v.strip()
    return s

def listfmt(s): return [x.strip() for x in re.split(r"[,\n]", s) if x.strip()] if s else []

# Auto-discover whichever .md holds the wiki-state block (prefix-agnostic)
state={}; state_file=None
for p in sorted(glob.glob(os.path.join(PROJ,"*.md"))):
    st=parse_state(read(p))
    if st: state, state_file = st, os.path.basename(p); break

actual={os.path.basename(p) for p in glob.glob(os.path.join(PROJ,"*"))}
expected=set(listfmt(state.get("expected_project_files",""))); wiki_files=set(listfmt(state.get("wiki_files","")))
red,yellow=[],[]
if not state: red.append("No wiki-state block found in any .md file")
mw=sorted(f for f in wiki_files if f not in actual)
if mw: red.append(f"Missing wiki file(s): {', '.join(mw)}")
rem=sorted(expected-actual); add=sorted(actual-expected-wiki_files)
if rem: red.append(f"Manifest files absent from project: {', '.join(rem)}")
if add: yellow.append(f"Uncataloged file(s) in project: {', '.join(add)}")
for wf in wiki_files:
    txt=read(os.path.join(PROJ,wf))
    for ref in set(re.findall(r"`([\w\-\.]+\.md)`", txt)):
        if ref in wiki_files and ref not in actual:
            red.append(f"{wf} references missing wiki file {ref}")
inv={}
for kv in re.split(r"[;\n]", state.get("invariants","")):
    if "=" in kv: k,v=kv.split("=",1); inv[k.strip()]=v.strip()
try:
    import openpyxl
    for fn,sheet,key in [("GTM_OS_Signal_Library_Metrics.xlsx","All Signals","signal_classes"),
                         ("Org_Capability_Metric_Library_v2_0.xlsx","All Metrics","org_metrics")]:
        p=os.path.join(PROJ,fn)
        if key in inv and os.path.exists(p):
            wb=openpyxl.load_workbook(p,data_only=True)
            if sheet in wb.sheetnames:
                rows=list(wb[sheet].iter_rows(values_only=True))
                ids=[r[0] for r in rows[1:] if r and r[0] and re.match(r"^[A-Z]+-L?\d",str(r[0]))]
                if str(len(ids))!=str(inv[key]): red.append(f"Invariant {key}={inv[key]} but source has {len(ids)}")
except ImportError:
    yellow.append("openpyxl absent: invariants not recomputed")
try: pending=int(state.get("pending_count","0"))
except ValueError: pending=0
if pending>=3: yellow.append(f"Sync debt: {pending} pending (>= threshold)")
verdict="RED" if red else ("YELLOW" if yellow else "GREEN")
print(f"WIKI HEALTH: {verdict}  (state {state_file or 'NONE'}, last_sync {state.get('last_sync','?')}, pending {state.get('pending_count','?')})")
for p in red: print("  RED   ·",p)
for p in yellow: print("  YELLOW·",p)
if verdict=="GREEN": print("  In sync. Proceed.")
```

---

## Domain Adaptation

| Domain | Tracker | Entities | Continuity focus |
|---|---|---|---|
| TV/Film | episode-tracker | characters | timeline, arcs, planted threads |
| Software | feature-tracker | architecture-entities | API contracts, migration state |
| Research | paper-tracker | concept-definitions | findings chain, methodology |
| Business | workstream-tracker | stakeholders | decisions, dependencies, blockers |
| Book/Novel | chapter-tracker | characters | timeline, foreshadowing |

Pattern: index → concepts → domain tracker → entities → continuity.

---

## Constraints

- Wiki files are orientation aids, not replacements for source. Verify against source before changing source.
- The session-start health check is non-optional in a wiki'd project. It is the first action, before requested work.
- The de-dup pass is a gate, not a virtue. Skipping it is the top failure mode.
- The pending-sync append is the minimum capture every changing session. Skipping it is the second failure mode.
- Quiet when GREEN. Loudness scales with severity, never with routine.
- No background execution exists. Bind integrity to the read-time trigger that always fires.

---

## Changelog

- **v2.1** · `wiki_` filename prefix convention for at-a-glance identifiability; audit script hardened to auto-discover the wiki-state block (prefix-agnostic, no hardcoded index filename).
- **v2.0** · Read-time health check with GREEN/YELLOW/RED tiers; machine-checkable Wiki State block (manifest + invariants); embedded audit script; pending-sync log for cheap per-session capture; sync-debt threshold forcing bounded consolidation; outputs-to-project gap handling; reference-integrity and invariant-reconciliation checks; file-type distinction (wiki vs compiled-source vs raw). De-dup and incremental update converted from soft guidance to checklists and mechanical triggers.
- **v1.0** · Five-file structure, read-wiki-first protocol, incremental and full-refresh maintenance, de-dup pass, relationship map, compounding-ROI model.
